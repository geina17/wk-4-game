CRYSTAL UNIVERSE FONT

Crystal Universe is a font that replicates the font used for the logo of the animated television show Steven Universe (tm).

Steven Universe (tm) was created by Rebecca Sugar.
STEVEN UNIVERSE and all related characters and elements are trademarks of and (c) Cartoon Network.

2015 - Created by MaxiGamer - maxigamer.deviantart.com
Made in FontForge (c).
